import { useEffect, useState } from "react";
import "./App.css";
import { DndContext } from "@dnd-kit/core";
import Column from "./column.jsx";

function App() {

  const columns = ["todo", "doing", "done"];
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState("");

  const groupedTasks = tasks.reduce((acc, task) => {

    if (!acc[task.status]) {
      acc[task.status] = [];
    }

    acc[task.status].push(task);

    return acc;

  }, {});

  function addTask() {

  if (!title.trim()) return;

  const newTask = {
    id: Date.now(),
    title,
    status: "todo"
  };

  setTasks([...tasks, newTask]);
  setTitle("");

}


  function handleDragEnd(event) {

    const taskId = event.active.id;
    const newStatus = event.over?.id;

    if (!newStatus) return;

    moveTask(taskId, newStatus);

  }

  function deleteTask(id) {
    setTasks(tasks.filter(task => task.id !== id));
  }

  function moveTask(id, status) {
    setTasks(tasks.map(task =>
      task.id === id ? { ...task, status } : task
    ));
  }

  return (

    <div className="kanban">

      <h1>Kanban</h1>

      <DndContext onDragEnd={handleDragEnd}>

        <div className="board">

          {columns.map(status => (

            <Column
              key={status}
              status={status}
              tasks={groupedTasks[status]}
              deleteTask={deleteTask}
            />

          ))}

        </div>

        <div className="input-area">

  <input
    type="text"
    placeholder="Nova tarefa"
    value={title}
    onChange={(e) => setTitle(e.target.value)}
  />

  <button onClick={addTask}>
    Adicionar
  </button>

</div>

      </DndContext>

    </div>

  );

}

export default App;