import { useDraggable } from "@dnd-kit/core";

function Task({ task, deleteTask }) {

  const { attributes, listeners, setNodeRef } = useDraggable({
    id: task.id
  });

  return (

    <div
      className="task"
      ref={setNodeRef}
      {...listeners}
      {...attributes}
    >

      {task.title}

      <div className="task-buttons">
        <button onClick={() => deleteTask(task.id)}>❌</button>
      </div>

    </div>

  );

}

export default Task;